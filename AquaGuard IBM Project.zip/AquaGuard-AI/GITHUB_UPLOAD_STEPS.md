# Publish AquaGuard AI on GitHub

## Upload the project
1. Sign in to https://github.com and choose **New repository**.
2. Name it `AquaGuard-AI`. Set it to **Public** if your internship reviewer must open it without signing in.
3. Do not initialize it with a README, license, or `.gitignore` (these are already included here).
4. Open this extracted `AquaGuard-AI` folder and upload its **contents** to the repository root. Ensure `index.html` is at the repository root, alongside `README.md`, `css/`, `js/`, `assets/`, `data/`, and `config/`.
5. Commit the files.

## Enable the live website (recommended)
1. In the repository, open **Settings → Pages**.
2. Under **Build and deployment**, choose **Deploy from a branch**.
3. Choose branch `main` and folder `/(root)`, then save.
4. Wait for GitHub Pages to finish publishing. The URL will be `https://YOUR-USERNAME.github.io/AquaGuard-AI/` if your repository is named `AquaGuard-AI`.
5. Open the actual URL in a private/incognito window and test the dashboard before submitting it.

## Important
- The project uses fictional synthetic demo data. Do not describe it as real-world water monitoring.
- Thresholds are marked unverified. AquaGuard AI is an educational preliminary screening tool, not a water-safety certification.
- Do not add passwords, API keys, or personal data to the repository.
